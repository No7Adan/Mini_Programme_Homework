import CustomPage from '../../../base/CustomPage'

CustomPage({
  onShareAppMessage() {
    return {
      title: 'footer',
      path: 'packageExtend/pages/base/footer/footer'
    }
  },
})
