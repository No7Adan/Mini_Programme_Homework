import CustomPage from '../../../base/CustomPage'

CustomPage({
  onShareAppMessage() {
    return {
      title: 'msg_fail',
      path: 'packageExtend/pages/operate/msg_fail/msg_fail'
    }
  },
})
