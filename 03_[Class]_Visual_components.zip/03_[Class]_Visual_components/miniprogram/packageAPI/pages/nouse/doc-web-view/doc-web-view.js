Page({
  onShareAppMessage() {
    return {
      title: '小程序接口文档',
      path: 'packageAPI/pages/doc-web-view/doc-web-view'
    }
  },
})
